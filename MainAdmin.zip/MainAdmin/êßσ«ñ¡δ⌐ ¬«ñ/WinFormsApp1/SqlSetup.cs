﻿using Microsoft.Data.SqlClient;
using System.ComponentModel.Design;
using System.Drawing.Text;
using System.Windows.Forms;
using System.Windows.Input;

namespace WinFormsApp1
{
    static class SqlSetup
    {
        static private SqlConnection sqlConnection;
        static SqlSetup()
        {
            sqlConnection = new SqlConnection(AppNuget.GetSerealizedString());
        }
        
        public static async void SetSqlInterface()
        {
            try
            {
                if (sqlConnection.State == System.Data.ConnectionState.Closed)
                {
                    await sqlConnection.OpenAsync();
                }
                using (SqlCommand sqlCommand = new SqlCommand("CREATE DATABASE ACCOUNTS COLLATE Cyrillic_General_100_CI_AS_SC_UTF8;", sqlConnection)) 
                {
                    await sqlCommand.ExecuteNonQueryAsync();
                }
                using (SqlCommand sqlCommand = new SqlCommand("USE ACCOUNTS CREATE TABLE ACCOUNTSINFO(USERID INT NOT NULL,USERLOGIN NVARCHAR(MAX) NOT NULL, USERPASSWORD NVARCHAR(MAX) NOT NULL);", sqlConnection))
                {
                    await sqlCommand.ExecuteNonQueryAsync();
                }
                using (SqlCommand sqlCommand = new SqlCommand("CREATE DATABASE TEACHERS COLLATE Cyrillic_General_100_CI_AS_SC_UTF8;", sqlConnection))
                {
                    await sqlCommand.ExecuteNonQueryAsync();
                }
                using (SqlCommand sqlCommand = new SqlCommand("USE TEACHERS CREATE TABLE PERSON(SNL NVARCHAR(MAX) NOT NULL);", sqlConnection))
                {
                    await sqlCommand.ExecuteNonQueryAsync();
                }
                using (SqlCommand sqlCommand = new SqlCommand("CREATE DATABASE CALLSCHEDULE COLLATE Cyrillic_General_100_CI_AS_SC_UTF8;", sqlConnection))
                {
                    await sqlCommand.ExecuteNonQueryAsync();
                }
                using (SqlCommand sqlCommand = new SqlCommand("USE CALLSCHEDULE CREATE TABLE CALLTIMES(STARTTIME NVARCHAR(MAX) NOT NULL, ENDTIME NVARCHAR(MAX) NOT NULL);", sqlConnection))
                {
                    await sqlCommand.ExecuteNonQueryAsync();
                }
                using (SqlCommand sqlCommand = new SqlCommand("CREATE DATABASE CLASSROOMS COLLATE Cyrillic_General_100_CI_AS_SC_UTF8;", sqlConnection))
                {
                    await sqlCommand.ExecuteNonQueryAsync();
                }
                using (SqlCommand sqlCommand = new SqlCommand("USE CLASSROOMS CREATE TABLE CLASSROOMTEACHER(TEACHER NVARCHAR(MAX) NOT NULL , CLASSROOM NVARCHAR(MAX) NOT NULL);", sqlConnection))
                {
                    await sqlCommand.ExecuteNonQueryAsync();
                }
                using (SqlCommand sqlCommand = new SqlCommand("CREATE DATABASE LESSONS COLLATE Cyrillic_General_100_CI_AS_SC_UTF8;", sqlConnection))
                {
                    await sqlCommand.ExecuteNonQueryAsync();
                }
                using (SqlCommand sqlCommand = new SqlCommand("USE LESSONS CREATE TABLE LESSONSITEMS(ITEMS NVARCHAR(MAX) NOT NULL);", sqlConnection))
                {
                    await sqlCommand.ExecuteNonQueryAsync();
                }
                using (SqlCommand sqlCommand = new SqlCommand("CREATE DATABASE ADS COLLATE Cyrillic_General_100_CI_AS_SC_UTF8;", sqlConnection))
                {
                    await sqlCommand.ExecuteNonQueryAsync();
                }
                using (SqlCommand sqlCommand = new SqlCommand("USE ADS CREATE TABLE INFO(TITLE NVARCHAR(MAX) NOT NULL,TEXT NVARCHAR(MAX) NOT NULL);", sqlConnection))
                {
                    await sqlCommand.ExecuteNonQueryAsync();
                }
                using (SqlCommand sqlCommand = new SqlCommand("CREATE DATABASE SCHOOLSCHEDULE COLLATE Cyrillic_General_100_CI_AS_SC_UTF8;", sqlConnection)) 
                {
                    await sqlCommand.ExecuteNonQueryAsync();
                }
                using (SqlCommand sqlCommand = new SqlCommand("CREATE DATABASE MARKS COLLATE Cyrillic_General_100_CI_AS_SC_UTF8;", sqlConnection))
                {
                    await sqlCommand.ExecuteNonQueryAsync();
                }
                using (SqlCommand sqlCommand = new SqlCommand("CREATE DATABASE CLASESITEMS COLLATE Cyrillic_General_100_CI_AS_SC_UTF8;", sqlConnection))
                {
                    await sqlCommand.ExecuteNonQueryAsync();
                }

                MessageBox.Show("Готово , теперь вы можете взаимодействовать с приложением!", "DataBase", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch(Exception ex) 
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (sqlConnection.State == System.Data.ConnectionState.Open)
                {
                    await sqlConnection.CloseAsync();
                }
            }
        }
        public static async void StartNonExecuteQuery(string command)
        {
            try
            {
                if (sqlConnection.State == System.Data.ConnectionState.Closed)
                {
                    await sqlConnection.OpenAsync();
                }

                using (SqlCommand sqlCommand = new SqlCommand(command, sqlConnection))
                {
                    await sqlCommand.ExecuteNonQueryAsync();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally 
            {
               await sqlConnection.CloseAsync();
            }
        }

        public static void AddTeacher(string surname , string name , string lastname) 
        {
            StartNonExecuteQuery($"USE TEACHERS INSERT INTO PERSON(SNL) VALUES('{surname} {name} {lastname}')");
        }

        public static async void AddClassroom(string command, string teacher)
        {
            try
            {
                if (sqlConnection.State == System.Data.ConnectionState.Closed)
                {
                    await sqlConnection.OpenAsync();
                }
                using (SqlCommand command1 = new($"USE CLASSROOMS CREATE TABLE {command}(SURNAME NVARCHAR(MAX) NOT NULL,NAME NVARCHAR(MAX) NOT NULL);", sqlConnection))
                {
                    await command1.ExecuteNonQueryAsync();
                }
                using (SqlCommand command1 = new($"USE CLASSROOMS INSERT INTO CLASSROOMTEACHER(TEACHER,CLASSROOM) VALUES('{teacher}','{command}');", sqlConnection))
                {
                   await command1.ExecuteNonQueryAsync();
                }
                using (SqlCommand sqlCommand = new SqlCommand($"USE SCHOOLSCHEDULE CREATE TABLE {command}(PONEDELNIK NVARCHAR(MAX),VTORNIK NVARCHAR(MAX),SREDA NVARCHAR(MAX),CHETVERG NVARCHAR(MAX),PYATNITZA NVARCHAR(MAX),SYBOTA NVARCHAR(MAX));", sqlConnection))
                {
                    await sqlCommand.ExecuteNonQueryAsync();
                }
                using (SqlCommand sqlCommand = new SqlCommand($"USE CLASESITEMS CREATE TABLE {command}(ITEMS NVARCHAR(MAX) NOT NULL);", sqlConnection))
                {
                    await sqlCommand.ExecuteNonQueryAsync();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                await sqlConnection.CloseAsync();
            }
        }
    }
}
