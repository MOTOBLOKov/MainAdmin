﻿namespace WinFormsApp1
{
    partial class MainAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainAdmin));
            panel1 = new Panel();
            button2 = new Button();
            tabControl2 = new TabControl();
            TabPage3 = new TabPage();
            button12 = new Button();
            textBox3 = new TextBox();
            tabPage4 = new TabPage();
            button13 = new Button();
            listBox2 = new ListBox();
            button14 = new Button();
            textBox1 = new TextBox();
            button1 = new Button();
            tabControl3 = new TabControl();
            tabPage5 = new TabPage();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            listBox12 = new ListBox();
            button7 = new Button();
            textBox2 = new TextBox();
            tabPage2 = new TabPage();
            pictureBox1 = new PictureBox();
            listBox1 = new ListBox();
            button8 = new Button();
            tabPage6 = new TabPage();
            tabControl4 = new TabControl();
            tabPage7 = new TabPage();
            textBox6 = new TextBox();
            textBox5 = new TextBox();
            label4 = new Label();
            button3 = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            textBox4 = new TextBox();
            tabPage8 = new TabPage();
            listBox3 = new ListBox();
            pictureBox2 = new PictureBox();
            button4 = new Button();
            tabPage9 = new TabPage();
            tabControl5 = new TabControl();
            tabPage13 = new TabPage();
            button5 = new Button();
            textBox8 = new TextBox();
            textBox7 = new TextBox();
            tabPage14 = new TabPage();
            pictureBox3 = new PictureBox();
            listBox4 = new ListBox();
            button6 = new Button();
            tabPage10 = new TabPage();
            tabControl6 = new TabControl();
            tabPage15 = new TabPage();
            pictureBox14 = new PictureBox();
            pictureBox13 = new PictureBox();
            label11 = new Label();
            listBox11 = new ListBox();
            listBox10 = new ListBox();
            listBox9 = new ListBox();
            listBox8 = new ListBox();
            listBox7 = new ListBox();
            comboBox4 = new ComboBox();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            pictureBox5 = new PictureBox();
            comboBox3 = new ComboBox();
            listBox6 = new ListBox();
            button9 = new Button();
            comboBox2 = new ComboBox();
            tabPage11 = new TabPage();
            tabControl7 = new TabControl();
            tabPage17 = new TabPage();
            pictureBox9 = new PictureBox();
            comboBox9 = new ComboBox();
            button11 = new Button();
            comboBox6 = new ComboBox();
            comboBox5 = new ComboBox();
            tabPage18 = new TabPage();
            listBox14 = new ListBox();
            pictureBox6 = new PictureBox();
            button15 = new Button();
            tabPage19 = new TabPage();
            tabControl8 = new TabControl();
            tabPage20 = new TabPage();
            pictureBox11 = new PictureBox();
            pictureBox10 = new PictureBox();
            button16 = new Button();
            textBox11 = new TextBox();
            textBox10 = new TextBox();
            listBox15 = new ListBox();
            pictureBox8 = new PictureBox();
            comboBox8 = new ComboBox();
            tabPage22 = new TabPage();
            pictureBox7 = new PictureBox();
            comboBox7 = new ComboBox();
            button18 = new Button();
            textBox12 = new TextBox();
            tabPage16 = new TabPage();
            tabControl10 = new TabControl();
            tabPage24 = new TabPage();
            comboBox10 = new ComboBox();
            listBox5 = new ListBox();
            button10 = new Button();
            pictureBox15 = new PictureBox();
            pictureBox4 = new PictureBox();
            comboBox1 = new ComboBox();
            tabPage12 = new TabPage();
            tabControl9 = new TabControl();
            tabPage21 = new TabPage();
            textBox13 = new TextBox();
            button17 = new Button();
            textBox9 = new TextBox();
            tabPage23 = new TabPage();
            listBox13 = new ListBox();
            pictureBox12 = new PictureBox();
            button19 = new Button();
            panel1.SuspendLayout();
            tabControl2.SuspendLayout();
            TabPage3.SuspendLayout();
            tabPage4.SuspendLayout();
            tabControl3.SuspendLayout();
            tabPage5.SuspendLayout();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            tabPage6.SuspendLayout();
            tabControl4.SuspendLayout();
            tabPage7.SuspendLayout();
            tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            tabPage9.SuspendLayout();
            tabControl5.SuspendLayout();
            tabPage13.SuspendLayout();
            tabPage14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            tabPage10.SuspendLayout();
            tabControl6.SuspendLayout();
            tabPage15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            tabPage11.SuspendLayout();
            tabControl7.SuspendLayout();
            tabPage17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            tabPage18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            tabPage19.SuspendLayout();
            tabControl8.SuspendLayout();
            tabPage20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            tabPage22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            tabPage16.SuspendLayout();
            tabControl10.SuspendLayout();
            tabPage24.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            tabPage12.SuspendLayout();
            tabControl9.SuspendLayout();
            tabPage21.SuspendLayout();
            tabPage23.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(64, 64, 64);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(tabControl2);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(button1);
            panel1.Dock = DockStyle.Top;
            panel1.ForeColor = Color.DimGray;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1098, 44);
            panel1.TabIndex = 0;
            // 
            // button2
            // 
            button2.BackColor = Color.White;
            button2.Dock = DockStyle.Top;
            button2.FlatStyle = FlatStyle.Popup;
            button2.ForeColor = SystemColors.Desktop;
            button2.Location = new Point(1019, 0);
            button2.Name = "button2";
            button2.Size = new Size(79, 44);
            button2.TabIndex = 6;
            button2.Text = "Настроить БД";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // tabControl2
            // 
            tabControl2.Controls.Add(TabPage3);
            tabControl2.Controls.Add(tabPage4);
            tabControl2.HotTrack = true;
            tabControl2.ItemSize = new Size(113, 30);
            tabControl2.Location = new Point(160, 44);
            tabControl2.Margin = new Padding(0);
            tabControl2.Name = "tabControl2";
            tabControl2.Padding = new Point(8, 3);
            tabControl2.SelectedIndex = 0;
            tabControl2.Size = new Size(829, 412);
            tabControl2.SizeMode = TabSizeMode.Fixed;
            tabControl2.TabIndex = 5;
            tabControl2.Visible = false;
            // 
            // TabPage3
            // 
            TabPage3.BackColor = Color.Gainsboro;
            TabPage3.Controls.Add(button12);
            TabPage3.Controls.Add(textBox3);
            TabPage3.Font = new Font("Agency FB", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            TabPage3.ForeColor = SystemColors.ControlText;
            TabPage3.Location = new Point(4, 34);
            TabPage3.Name = "TabPage3";
            TabPage3.Padding = new Padding(3);
            TabPage3.Size = new Size(821, 374);
            TabPage3.TabIndex = 0;
            TabPage3.Text = "Добавить учителя";
            // 
            // button12
            // 
            button12.FlatStyle = FlatStyle.System;
            button12.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button12.Location = new Point(6, 70);
            button12.Name = "button12";
            button12.Size = new Size(216, 58);
            button12.TabIndex = 1;
            button12.Text = "добавить";
            button12.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            textBox3.Dock = DockStyle.Top;
            textBox3.Font = new Font("Arial", 27.75F, FontStyle.Regular, GraphicsUnit.Point, 204);
            textBox3.Location = new Point(3, 3);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(815, 58);
            textBox3.TabIndex = 0;
            // 
            // tabPage4
            // 
            tabPage4.BackColor = Color.LightGray;
            tabPage4.Controls.Add(button13);
            tabPage4.Controls.Add(listBox2);
            tabPage4.Controls.Add(button14);
            tabPage4.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            tabPage4.Location = new Point(4, 34);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(821, 374);
            tabPage4.TabIndex = 1;
            tabPage4.Text = "Удалить учителя";
            // 
            // button13
            // 
            button13.Dock = DockStyle.Bottom;
            button13.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button13.Location = new Point(3, 321);
            button13.Name = "button13";
            button13.Size = new Size(815, 50);
            button13.TabIndex = 4;
            button13.Text = "обновить";
            button13.UseVisualStyleBackColor = true;
            // 
            // listBox2
            // 
            listBox2.Dock = DockStyle.Fill;
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 25;
            listBox2.Location = new Point(3, 44);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(815, 327);
            listBox2.TabIndex = 3;
            // 
            // button14
            // 
            button14.Dock = DockStyle.Top;
            button14.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button14.Location = new Point(3, 3);
            button14.Name = "button14";
            button14.Size = new Size(815, 41);
            button14.TabIndex = 2;
            button14.Text = "удалить";
            button14.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            textBox1.AutoCompleteMode = AutoCompleteMode.Suggest;
            textBox1.BorderStyle = BorderStyle.FixedSingle;
            textBox1.Cursor = Cursors.IBeam;
            textBox1.Dock = DockStyle.Left;
            textBox1.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 204);
            textBox1.Location = new Point(135, 0);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.ScrollBars = ScrollBars.Vertical;
            textBox1.Size = new Size(884, 44);
            textBox1.TabIndex = 1;
            textBox1.Text = "Введите строку подключения...";
            // 
            // button1
            // 
            button1.BackColor = Color.White;
            button1.BackgroundImageLayout = ImageLayout.None;
            button1.Dock = DockStyle.Left;
            button1.FlatStyle = FlatStyle.Popup;
            button1.ForeColor = SystemColors.InfoText;
            button1.Location = new Point(0, 0);
            button1.Name = "button1";
            button1.Size = new Size(135, 44);
            button1.TabIndex = 0;
            button1.Text = "Сохранить...";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // tabControl3
            // 
            tabControl3.Controls.Add(tabPage5);
            tabControl3.Controls.Add(tabPage6);
            tabControl3.Controls.Add(tabPage9);
            tabControl3.Controls.Add(tabPage10);
            tabControl3.Controls.Add(tabPage11);
            tabControl3.Controls.Add(tabPage12);
            tabControl3.Dock = DockStyle.Fill;
            tabControl3.ItemSize = new Size(135, 40);
            tabControl3.Location = new Point(0, 44);
            tabControl3.Name = "tabControl3";
            tabControl3.SelectedIndex = 0;
            tabControl3.Size = new Size(1098, 733);
            tabControl3.SizeMode = TabSizeMode.Fixed;
            tabControl3.TabIndex = 5;
            // 
            // tabPage5
            // 
            tabPage5.Controls.Add(tabControl1);
            tabPage5.Location = new Point(4, 44);
            tabPage5.Name = "tabPage5";
            tabPage5.Padding = new Padding(3);
            tabPage5.Size = new Size(1090, 685);
            tabPage5.TabIndex = 0;
            tabPage5.Text = "Предметы";
            tabPage5.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.HotTrack = true;
            tabControl1.ItemSize = new Size(130, 30);
            tabControl1.Location = new Point(3, 3);
            tabControl1.Margin = new Padding(0);
            tabControl1.Name = "tabControl1";
            tabControl1.Padding = new Point(8, 3);
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1084, 679);
            tabControl1.SizeMode = TabSizeMode.Fixed;
            tabControl1.TabIndex = 4;
            // 
            // tabPage1
            // 
            tabPage1.AllowDrop = true;
            tabPage1.BackColor = Color.GhostWhite;
            tabPage1.Controls.Add(listBox12);
            tabPage1.Controls.Add(button7);
            tabPage1.Controls.Add(textBox2);
            tabPage1.Font = new Font("Agency FB", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            tabPage1.ForeColor = SystemColors.ControlText;
            tabPage1.ImeMode = ImeMode.On;
            tabPage1.Location = new Point(4, 34);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(1076, 641);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Добавить предмет";
            // 
            // listBox12
            // 
            listBox12.Cursor = Cursors.No;
            listBox12.Dock = DockStyle.Fill;
            listBox12.Font = new Font("Agency FB", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            listBox12.FormattingEnabled = true;
            listBox12.ItemHeight = 28;
            listBox12.Items.AddRange(new object[] { "Список текущих предметов:" });
            listBox12.Location = new Point(3, 103);
            listBox12.Name = "listBox12";
            listBox12.Size = new Size(1070, 535);
            listBox12.TabIndex = 4;
            // 
            // button7
            // 
            button7.Dock = DockStyle.Top;
            button7.FlatStyle = FlatStyle.Popup;
            button7.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button7.Location = new Point(3, 45);
            button7.Name = "button7";
            button7.Size = new Size(1070, 58);
            button7.TabIndex = 1;
            button7.Text = "добавить";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // textBox2
            // 
            textBox2.Cursor = Cursors.IBeam;
            textBox2.Dock = DockStyle.Top;
            textBox2.Font = new Font("Arial", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            textBox2.Location = new Point(3, 3);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(1070, 42);
            textBox2.TabIndex = 0;
            textBox2.Text = "Введите название предмета...";
            // 
            // tabPage2
            // 
            tabPage2.BackColor = Color.White;
            tabPage2.Controls.Add(pictureBox1);
            tabPage2.Controls.Add(listBox1);
            tabPage2.Controls.Add(button8);
            tabPage2.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            tabPage2.Location = new Point(4, 34);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(1076, 641);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Удалить предмет";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.White;
            pictureBox1.BorderStyle = BorderStyle.Fixed3D;
            pictureBox1.Dock = DockStyle.Bottom;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(3, 598);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1070, 40);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click_1;
            // 
            // listBox1
            // 
            listBox1.Dock = DockStyle.Fill;
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 25;
            listBox1.Location = new Point(3, 52);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(1070, 586);
            listBox1.TabIndex = 3;
            // 
            // button8
            // 
            button8.AutoSize = true;
            button8.BackColor = Color.WhiteSmoke;
            button8.BackgroundImageLayout = ImageLayout.Center;
            button8.Dock = DockStyle.Top;
            button8.FlatStyle = FlatStyle.Popup;
            button8.Font = new Font("Microsoft JhengHei", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button8.Location = new Point(3, 3);
            button8.Name = "button8";
            button8.Size = new Size(1070, 49);
            button8.TabIndex = 2;
            button8.Text = "удалить";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click_1;
            // 
            // tabPage6
            // 
            tabPage6.Controls.Add(tabControl4);
            tabPage6.Location = new Point(4, 44);
            tabPage6.Name = "tabPage6";
            tabPage6.Padding = new Padding(3);
            tabPage6.Size = new Size(1090, 685);
            tabPage6.TabIndex = 1;
            tabPage6.Text = "Учителя";
            tabPage6.UseVisualStyleBackColor = true;
            // 
            // tabControl4
            // 
            tabControl4.Controls.Add(tabPage7);
            tabControl4.Controls.Add(tabPage8);
            tabControl4.Dock = DockStyle.Fill;
            tabControl4.HotTrack = true;
            tabControl4.ItemSize = new Size(130, 30);
            tabControl4.Location = new Point(3, 3);
            tabControl4.Margin = new Padding(0);
            tabControl4.Name = "tabControl4";
            tabControl4.Padding = new Point(8, 3);
            tabControl4.SelectedIndex = 0;
            tabControl4.Size = new Size(1084, 679);
            tabControl4.SizeMode = TabSizeMode.Fixed;
            tabControl4.TabIndex = 5;
            // 
            // tabPage7
            // 
            tabPage7.AllowDrop = true;
            tabPage7.BackColor = Color.GhostWhite;
            tabPage7.Controls.Add(textBox6);
            tabPage7.Controls.Add(textBox5);
            tabPage7.Controls.Add(label4);
            tabPage7.Controls.Add(button3);
            tabPage7.Controls.Add(label3);
            tabPage7.Controls.Add(label2);
            tabPage7.Controls.Add(label1);
            tabPage7.Controls.Add(textBox4);
            tabPage7.Font = new Font("Agency FB", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            tabPage7.ForeColor = SystemColors.ControlText;
            tabPage7.ImeMode = ImeMode.On;
            tabPage7.Location = new Point(4, 34);
            tabPage7.Name = "tabPage7";
            tabPage7.Padding = new Padding(3);
            tabPage7.Size = new Size(1076, 641);
            tabPage7.TabIndex = 0;
            tabPage7.Text = "Добавить учителя";
            // 
            // textBox6
            // 
            textBox6.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox6.Location = new Point(7, 102);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(330, 39);
            textBox6.TabIndex = 11;
            // 
            // textBox5
            // 
            textBox5.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox5.Location = new Point(7, 57);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(330, 39);
            textBox5.TabIndex = 10;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft JhengHei", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(343, 55);
            label4.Name = "label4";
            label4.Size = new Size(93, 36);
            label4.TabIndex = 9;
            label4.Text = "- Имя";
            // 
            // button3
            // 
            button3.Dock = DockStyle.Bottom;
            button3.FlatStyle = FlatStyle.Popup;
            button3.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button3.Location = new Point(3, 580);
            button3.Name = "button3";
            button3.Size = new Size(1070, 58);
            button3.TabIndex = 6;
            button3.Text = "добавить";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft JhengHei", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(342, 100);
            label3.Name = "label3";
            label3.Size = new Size(161, 36);
            label3.TabIndex = 5;
            label3.Text = "- Отчество";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft JhengHei", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(342, 51);
            label2.Name = "label2";
            label2.Size = new Size(0, 36);
            label2.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft JhengHei", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(343, 12);
            label1.Name = "label1";
            label1.Size = new Size(162, 36);
            label1.TabIndex = 3;
            label1.Text = "- Фамилия";
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox4.Location = new Point(6, 12);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(330, 39);
            textBox4.TabIndex = 0;
            // 
            // tabPage8
            // 
            tabPage8.BackColor = Color.White;
            tabPage8.Controls.Add(listBox3);
            tabPage8.Controls.Add(pictureBox2);
            tabPage8.Controls.Add(button4);
            tabPage8.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            tabPage8.Location = new Point(4, 34);
            tabPage8.Name = "tabPage8";
            tabPage8.Padding = new Padding(3);
            tabPage8.Size = new Size(1076, 641);
            tabPage8.TabIndex = 1;
            tabPage8.Text = "Удалить учителя";
            // 
            // listBox3
            // 
            listBox3.Dock = DockStyle.Fill;
            listBox3.FormattingEnabled = true;
            listBox3.ItemHeight = 25;
            listBox3.Location = new Point(3, 52);
            listBox3.Name = "listBox3";
            listBox3.Size = new Size(1070, 546);
            listBox3.TabIndex = 6;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.White;
            pictureBox2.BorderStyle = BorderStyle.Fixed3D;
            pictureBox2.Dock = DockStyle.Bottom;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(3, 598);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(1070, 40);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 5;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // button4
            // 
            button4.AutoSize = true;
            button4.BackColor = Color.WhiteSmoke;
            button4.BackgroundImageLayout = ImageLayout.Center;
            button4.Dock = DockStyle.Top;
            button4.FlatStyle = FlatStyle.Popup;
            button4.Font = new Font("Microsoft JhengHei", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button4.Location = new Point(3, 3);
            button4.Name = "button4";
            button4.Size = new Size(1070, 49);
            button4.TabIndex = 3;
            button4.Text = "удалить";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // tabPage9
            // 
            tabPage9.Controls.Add(tabControl5);
            tabPage9.Location = new Point(4, 44);
            tabPage9.Name = "tabPage9";
            tabPage9.Size = new Size(1090, 685);
            tabPage9.TabIndex = 2;
            tabPage9.Text = "Расписание звонков";
            tabPage9.UseVisualStyleBackColor = true;
            // 
            // tabControl5
            // 
            tabControl5.Controls.Add(tabPage13);
            tabControl5.Controls.Add(tabPage14);
            tabControl5.Dock = DockStyle.Fill;
            tabControl5.HotTrack = true;
            tabControl5.ItemSize = new Size(130, 30);
            tabControl5.Location = new Point(0, 0);
            tabControl5.Margin = new Padding(0);
            tabControl5.Name = "tabControl5";
            tabControl5.Padding = new Point(8, 3);
            tabControl5.SelectedIndex = 0;
            tabControl5.Size = new Size(1090, 685);
            tabControl5.SizeMode = TabSizeMode.Fixed;
            tabControl5.TabIndex = 5;
            // 
            // tabPage13
            // 
            tabPage13.AllowDrop = true;
            tabPage13.BackColor = Color.GhostWhite;
            tabPage13.Controls.Add(button5);
            tabPage13.Controls.Add(textBox8);
            tabPage13.Controls.Add(textBox7);
            tabPage13.Font = new Font("Agency FB", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            tabPage13.ForeColor = SystemColors.ControlText;
            tabPage13.ImeMode = ImeMode.On;
            tabPage13.Location = new Point(4, 34);
            tabPage13.Name = "tabPage13";
            tabPage13.Padding = new Padding(3);
            tabPage13.Size = new Size(1082, 647);
            tabPage13.TabIndex = 0;
            tabPage13.Text = "Добавить расписание";
            // 
            // button5
            // 
            button5.FlatStyle = FlatStyle.Popup;
            button5.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button5.Location = new Point(6, 96);
            button5.Name = "button5";
            button5.Size = new Size(330, 48);
            button5.TabIndex = 7;
            button5.Text = "добавить";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // textBox8
            // 
            textBox8.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox8.Location = new Point(6, 51);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(330, 39);
            textBox8.TabIndex = 2;
            textBox8.Text = "Конец урока...";
            // 
            // textBox7
            // 
            textBox7.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox7.Location = new Point(6, 6);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(330, 39);
            textBox7.TabIndex = 1;
            textBox7.Text = "Начало урока...";
            // 
            // tabPage14
            // 
            tabPage14.BackColor = Color.White;
            tabPage14.Controls.Add(pictureBox3);
            tabPage14.Controls.Add(listBox4);
            tabPage14.Controls.Add(button6);
            tabPage14.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            tabPage14.Location = new Point(4, 34);
            tabPage14.Name = "tabPage14";
            tabPage14.Padding = new Padding(3);
            tabPage14.Size = new Size(1082, 647);
            tabPage14.TabIndex = 1;
            tabPage14.Text = "Удалить расписание";
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = Color.White;
            pictureBox3.BorderStyle = BorderStyle.Fixed3D;
            pictureBox3.Dock = DockStyle.Bottom;
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(3, 604);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(1076, 40);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 4;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // listBox4
            // 
            listBox4.Dock = DockStyle.Fill;
            listBox4.FormattingEnabled = true;
            listBox4.ItemHeight = 25;
            listBox4.Location = new Point(3, 52);
            listBox4.Name = "listBox4";
            listBox4.Size = new Size(1076, 592);
            listBox4.TabIndex = 3;
            // 
            // button6
            // 
            button6.AutoSize = true;
            button6.BackColor = Color.WhiteSmoke;
            button6.BackgroundImageLayout = ImageLayout.Center;
            button6.Dock = DockStyle.Top;
            button6.FlatStyle = FlatStyle.Popup;
            button6.Font = new Font("Microsoft JhengHei", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button6.Location = new Point(3, 3);
            button6.Name = "button6";
            button6.Size = new Size(1076, 49);
            button6.TabIndex = 2;
            button6.Text = "удалить";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // tabPage10
            // 
            tabPage10.Controls.Add(tabControl6);
            tabPage10.Location = new Point(4, 44);
            tabPage10.Name = "tabPage10";
            tabPage10.Size = new Size(1090, 685);
            tabPage10.TabIndex = 3;
            tabPage10.Text = "Расписание уроков";
            tabPage10.UseVisualStyleBackColor = true;
            // 
            // tabControl6
            // 
            tabControl6.Controls.Add(tabPage15);
            tabControl6.Dock = DockStyle.Fill;
            tabControl6.HotTrack = true;
            tabControl6.ItemSize = new Size(130, 30);
            tabControl6.Location = new Point(0, 0);
            tabControl6.Margin = new Padding(0);
            tabControl6.Name = "tabControl6";
            tabControl6.Padding = new Point(8, 3);
            tabControl6.SelectedIndex = 0;
            tabControl6.Size = new Size(1090, 685);
            tabControl6.SizeMode = TabSizeMode.Fixed;
            tabControl6.TabIndex = 6;
            // 
            // tabPage15
            // 
            tabPage15.AllowDrop = true;
            tabPage15.BackColor = Color.GhostWhite;
            tabPage15.Controls.Add(pictureBox14);
            tabPage15.Controls.Add(pictureBox13);
            tabPage15.Controls.Add(label11);
            tabPage15.Controls.Add(listBox11);
            tabPage15.Controls.Add(listBox10);
            tabPage15.Controls.Add(listBox9);
            tabPage15.Controls.Add(listBox8);
            tabPage15.Controls.Add(listBox7);
            tabPage15.Controls.Add(comboBox4);
            tabPage15.Controls.Add(label10);
            tabPage15.Controls.Add(label9);
            tabPage15.Controls.Add(label8);
            tabPage15.Controls.Add(label7);
            tabPage15.Controls.Add(label6);
            tabPage15.Controls.Add(label5);
            tabPage15.Controls.Add(pictureBox5);
            tabPage15.Controls.Add(comboBox3);
            tabPage15.Controls.Add(listBox6);
            tabPage15.Controls.Add(button9);
            tabPage15.Controls.Add(comboBox2);
            tabPage15.Font = new Font("Agency FB", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            tabPage15.ForeColor = SystemColors.ControlText;
            tabPage15.ImeMode = ImeMode.On;
            tabPage15.Location = new Point(4, 34);
            tabPage15.Name = "tabPage15";
            tabPage15.Padding = new Padding(3);
            tabPage15.Size = new Size(1082, 647);
            tabPage15.TabIndex = 0;
            tabPage15.Text = "Создать расписание";
            // 
            // pictureBox14
            // 
            pictureBox14.BackColor = Color.White;
            pictureBox14.BorderStyle = BorderStyle.Fixed3D;
            pictureBox14.Dock = DockStyle.Left;
            pictureBox14.Image = (Image)resources.GetObject("pictureBox14.Image");
            pictureBox14.Location = new Point(3, 3);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new Size(49, 566);
            pictureBox14.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox14.TabIndex = 29;
            pictureBox14.TabStop = false;
            pictureBox14.Click += pictureBox14_Click;
            // 
            // pictureBox13
            // 
            pictureBox13.BackColor = Color.White;
            pictureBox13.BorderStyle = BorderStyle.Fixed3D;
            pictureBox13.Dock = DockStyle.Bottom;
            pictureBox13.Image = (Image)resources.GetObject("pictureBox13.Image");
            pictureBox13.Location = new Point(3, 569);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(1076, 46);
            pictureBox13.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox13.TabIndex = 28;
            pictureBox13.TabStop = false;
            pictureBox13.Click += pictureBox13_Click;
            // 
            // label11
            // 
            label11.BackColor = Color.Gray;
            label11.Dock = DockStyle.Bottom;
            label11.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label11.Location = new Point(3, 615);
            label11.Name = "label11";
            label11.Size = new Size(1076, 29);
            label11.TabIndex = 27;
            label11.Text = "_____________________";
            label11.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // listBox11
            // 
            listBox11.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            listBox11.FormattingEnabled = true;
            listBox11.ItemHeight = 27;
            listBox11.Location = new Point(384, 337);
            listBox11.Name = "listBox11";
            listBox11.Size = new Size(157, 220);
            listBox11.TabIndex = 26;
            listBox11.SelectedIndexChanged += listBox11_SelectedIndexChanged;
            // 
            // listBox10
            // 
            listBox10.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            listBox10.FormattingEnabled = true;
            listBox10.ItemHeight = 27;
            listBox10.Location = new Point(221, 337);
            listBox10.Name = "listBox10";
            listBox10.Size = new Size(157, 220);
            listBox10.TabIndex = 25;
            listBox10.SelectedIndexChanged += listBox10_SelectedIndexChanged;
            // 
            // listBox9
            // 
            listBox9.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            listBox9.FormattingEnabled = true;
            listBox9.ItemHeight = 27;
            listBox9.Location = new Point(58, 336);
            listBox9.Name = "listBox9";
            listBox9.Size = new Size(157, 220);
            listBox9.TabIndex = 24;
            listBox9.SelectedIndexChanged += listBox9_SelectedIndexChanged;
            // 
            // listBox8
            // 
            listBox8.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            listBox8.FormattingEnabled = true;
            listBox8.ItemHeight = 27;
            listBox8.Location = new Point(384, 84);
            listBox8.Name = "listBox8";
            listBox8.Size = new Size(157, 220);
            listBox8.TabIndex = 23;
            listBox8.SelectedIndexChanged += listBox8_SelectedIndexChanged;
            // 
            // listBox7
            // 
            listBox7.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            listBox7.FormattingEnabled = true;
            listBox7.ItemHeight = 27;
            listBox7.Location = new Point(221, 84);
            listBox7.Name = "listBox7";
            listBox7.Size = new Size(157, 220);
            listBox7.TabIndex = 22;
            listBox7.SelectedIndexChanged += listBox7_SelectedIndexChanged;
            // 
            // comboBox4
            // 
            comboBox4.AllowDrop = true;
            comboBox4.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox4.FormattingEnabled = true;
            comboBox4.Location = new Point(58, 3);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new Size(203, 35);
            comboBox4.TabIndex = 21;
            comboBox4.Text = "Класс";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.Location = new Point(384, 307);
            label10.Name = "label10";
            label10.Size = new Size(96, 27);
            label10.TabIndex = 20;
            label10.Text = "Суббота";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.Location = new Point(220, 307);
            label9.Name = "label9";
            label9.Size = new Size(96, 27);
            label9.TabIndex = 19;
            label9.Text = "Пятница";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(58, 307);
            label8.Name = "label8";
            label8.Size = new Size(91, 27);
            label8.TabIndex = 18;
            label8.Text = "Четверг";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(384, 52);
            label7.Name = "label7";
            label7.Size = new Size(75, 27);
            label7.TabIndex = 17;
            label7.Text = "Среда";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(58, 52);
            label6.Name = "label6";
            label6.Size = new Size(145, 27);
            label6.TabIndex = 16;
            label6.Text = "Понедельник";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(221, 49);
            label5.Name = "label5";
            label5.Size = new Size(95, 27);
            label5.TabIndex = 15;
            label5.Text = "Вторник";
            // 
            // pictureBox5
            // 
            pictureBox5.BackColor = Color.White;
            pictureBox5.BorderStyle = BorderStyle.Fixed3D;
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(685, 3);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(39, 35);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 14;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // comboBox3
            // 
            comboBox3.AllowDrop = true;
            comboBox3.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox3.FormattingEnabled = true;
            comboBox3.Location = new Point(267, 3);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(203, 35);
            comboBox3.TabIndex = 13;
            comboBox3.Text = "Урок";
            // 
            // listBox6
            // 
            listBox6.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            listBox6.FormattingEnabled = true;
            listBox6.ItemHeight = 27;
            listBox6.Location = new Point(58, 84);
            listBox6.Name = "listBox6";
            listBox6.Size = new Size(157, 220);
            listBox6.TabIndex = 7;
            listBox6.SelectedIndexChanged += listBox6_SelectedIndexChanged;
            // 
            // button9
            // 
            button9.AllowDrop = true;
            button9.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            button9.BackColor = Color.WhiteSmoke;
            button9.BackgroundImageLayout = ImageLayout.Center;
            button9.FlatStyle = FlatStyle.Popup;
            button9.Font = new Font("Microsoft JhengHei", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button9.Location = new Point(730, 3);
            button9.Name = "button9";
            button9.Size = new Size(87, 35);
            button9.TabIndex = 3;
            button9.Text = "!Добавить";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button9_Click;
            // 
            // comboBox2
            // 
            comboBox2.AllowDrop = true;
            comboBox2.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота" });
            comboBox2.Location = new Point(476, 3);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(203, 35);
            comboBox2.TabIndex = 1;
            comboBox2.Text = "День недели";
            // 
            // tabPage11
            // 
            tabPage11.Controls.Add(tabControl7);
            tabPage11.Location = new Point(4, 44);
            tabPage11.Name = "tabPage11";
            tabPage11.Size = new Size(1090, 685);
            tabPage11.TabIndex = 4;
            tabPage11.Text = "Классы";
            tabPage11.UseVisualStyleBackColor = true;
            // 
            // tabControl7
            // 
            tabControl7.Controls.Add(tabPage17);
            tabControl7.Controls.Add(tabPage18);
            tabControl7.Controls.Add(tabPage19);
            tabControl7.Controls.Add(tabPage16);
            tabControl7.Dock = DockStyle.Fill;
            tabControl7.HotTrack = true;
            tabControl7.ItemSize = new Size(130, 30);
            tabControl7.Location = new Point(0, 0);
            tabControl7.Margin = new Padding(0);
            tabControl7.Name = "tabControl7";
            tabControl7.Padding = new Point(8, 3);
            tabControl7.SelectedIndex = 0;
            tabControl7.Size = new Size(1090, 685);
            tabControl7.SizeMode = TabSizeMode.Fixed;
            tabControl7.TabIndex = 5;
            // 
            // tabPage17
            // 
            tabPage17.AllowDrop = true;
            tabPage17.BackColor = Color.GhostWhite;
            tabPage17.Controls.Add(pictureBox9);
            tabPage17.Controls.Add(comboBox9);
            tabPage17.Controls.Add(button11);
            tabPage17.Controls.Add(comboBox6);
            tabPage17.Controls.Add(comboBox5);
            tabPage17.Font = new Font("Agency FB", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            tabPage17.ForeColor = SystemColors.ControlText;
            tabPage17.ImeMode = ImeMode.On;
            tabPage17.Location = new Point(4, 34);
            tabPage17.Name = "tabPage17";
            tabPage17.Padding = new Padding(3);
            tabPage17.Size = new Size(1082, 647);
            tabPage17.TabIndex = 0;
            tabPage17.Text = "Добавить класс";
            // 
            // pictureBox9
            // 
            pictureBox9.BackColor = Color.White;
            pictureBox9.BorderStyle = BorderStyle.Fixed3D;
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(760, 11);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(39, 35);
            pictureBox9.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox9.TabIndex = 15;
            pictureBox9.TabStop = false;
            pictureBox9.Click += pictureBox9_Click;
            // 
            // comboBox9
            // 
            comboBox9.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox9.FormattingEnabled = true;
            comboBox9.Location = new Point(342, 11);
            comboBox9.Name = "comboBox9";
            comboBox9.Size = new Size(412, 35);
            comboBox9.TabIndex = 9;
            comboBox9.Text = "Учитель";
            // 
            // button11
            // 
            button11.FlatStyle = FlatStyle.Popup;
            button11.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button11.Location = new Point(6, 52);
            button11.Name = "button11";
            button11.Size = new Size(793, 48);
            button11.TabIndex = 8;
            button11.Text = "добавить";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click;
            // 
            // comboBox6
            // 
            comboBox6.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox6.FormattingEnabled = true;
            comboBox6.Items.AddRange(new object[] { "А", "Б", "В", "Г", "Е" });
            comboBox6.Location = new Point(236, 10);
            comboBox6.Name = "comboBox6";
            comboBox6.Size = new Size(100, 35);
            comboBox6.TabIndex = 3;
            comboBox6.Text = "Буква";
            // 
            // comboBox5
            // 
            comboBox5.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox5.FormattingEnabled = true;
            comboBox5.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11" });
            comboBox5.Location = new Point(6, 10);
            comboBox5.Name = "comboBox5";
            comboBox5.Size = new Size(224, 35);
            comboBox5.TabIndex = 2;
            comboBox5.Text = "Номер класса";
            // 
            // tabPage18
            // 
            tabPage18.BackColor = Color.White;
            tabPage18.Controls.Add(listBox14);
            tabPage18.Controls.Add(pictureBox6);
            tabPage18.Controls.Add(button15);
            tabPage18.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            tabPage18.Location = new Point(4, 34);
            tabPage18.Name = "tabPage18";
            tabPage18.Padding = new Padding(3);
            tabPage18.Size = new Size(1082, 647);
            tabPage18.TabIndex = 1;
            tabPage18.Text = "Удалить класс";
            // 
            // listBox14
            // 
            listBox14.Dock = DockStyle.Fill;
            listBox14.FormattingEnabled = true;
            listBox14.ItemHeight = 25;
            listBox14.Location = new Point(3, 52);
            listBox14.Name = "listBox14";
            listBox14.Size = new Size(1076, 552);
            listBox14.TabIndex = 5;
            listBox14.SelectedIndexChanged += listBox14_SelectedIndexChanged;
            // 
            // pictureBox6
            // 
            pictureBox6.BackColor = Color.White;
            pictureBox6.BorderStyle = BorderStyle.Fixed3D;
            pictureBox6.Dock = DockStyle.Bottom;
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(3, 604);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(1076, 40);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 4;
            pictureBox6.TabStop = false;
            pictureBox6.Click += pictureBox6_Click;
            // 
            // button15
            // 
            button15.AutoSize = true;
            button15.BackColor = Color.WhiteSmoke;
            button15.BackgroundImageLayout = ImageLayout.Center;
            button15.Dock = DockStyle.Top;
            button15.FlatStyle = FlatStyle.Popup;
            button15.Font = new Font("Microsoft JhengHei", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button15.Location = new Point(3, 3);
            button15.Name = "button15";
            button15.Size = new Size(1076, 49);
            button15.TabIndex = 2;
            button15.Text = "удалить";
            button15.UseVisualStyleBackColor = false;
            button15.Click += button15_Click;
            // 
            // tabPage19
            // 
            tabPage19.Controls.Add(tabControl8);
            tabPage19.Location = new Point(4, 34);
            tabPage19.Name = "tabPage19";
            tabPage19.Size = new Size(1082, 647);
            tabPage19.TabIndex = 2;
            tabPage19.Text = "Учащиеся";
            tabPage19.UseVisualStyleBackColor = true;
            // 
            // tabControl8
            // 
            tabControl8.Controls.Add(tabPage20);
            tabControl8.Controls.Add(tabPage22);
            tabControl8.Dock = DockStyle.Fill;
            tabControl8.HotTrack = true;
            tabControl8.ItemSize = new Size(130, 30);
            tabControl8.Location = new Point(0, 0);
            tabControl8.Margin = new Padding(0);
            tabControl8.Name = "tabControl8";
            tabControl8.Padding = new Point(8, 3);
            tabControl8.SelectedIndex = 0;
            tabControl8.Size = new Size(1082, 647);
            tabControl8.SizeMode = TabSizeMode.Fixed;
            tabControl8.TabIndex = 6;
            // 
            // tabPage20
            // 
            tabPage20.AllowDrop = true;
            tabPage20.BackColor = Color.GhostWhite;
            tabPage20.Controls.Add(pictureBox11);
            tabPage20.Controls.Add(pictureBox10);
            tabPage20.Controls.Add(button16);
            tabPage20.Controls.Add(textBox11);
            tabPage20.Controls.Add(textBox10);
            tabPage20.Controls.Add(listBox15);
            tabPage20.Controls.Add(pictureBox8);
            tabPage20.Controls.Add(comboBox8);
            tabPage20.Font = new Font("Agency FB", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            tabPage20.ForeColor = SystemColors.ControlText;
            tabPage20.ImeMode = ImeMode.On;
            tabPage20.Location = new Point(4, 34);
            tabPage20.Name = "tabPage20";
            tabPage20.Padding = new Padding(3);
            tabPage20.Size = new Size(1074, 609);
            tabPage20.TabIndex = 0;
            tabPage20.Text = "Редак.учащихся";
            // 
            // pictureBox11
            // 
            pictureBox11.BackColor = Color.White;
            pictureBox11.BorderStyle = BorderStyle.Fixed3D;
            pictureBox11.Dock = DockStyle.Left;
            pictureBox11.Image = (Image)resources.GetObject("pictureBox11.Image");
            pictureBox11.Location = new Point(324, 164);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(36, 442);
            pictureBox11.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox11.TabIndex = 24;
            pictureBox11.TabStop = false;
            pictureBox11.Click += pictureBox11_Click_1;
            // 
            // pictureBox10
            // 
            pictureBox10.BackColor = Color.White;
            pictureBox10.BorderStyle = BorderStyle.Fixed3D;
            pictureBox10.Dock = DockStyle.Left;
            pictureBox10.Image = (Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new Point(285, 164);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(39, 442);
            pictureBox10.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox10.TabIndex = 22;
            pictureBox10.TabStop = false;
            pictureBox10.Click += pictureBox10_Click;
            // 
            // button16
            // 
            button16.Dock = DockStyle.Top;
            button16.FlatStyle = FlatStyle.Popup;
            button16.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button16.Location = new Point(285, 116);
            button16.Name = "button16";
            button16.Size = new Size(747, 48);
            button16.TabIndex = 21;
            button16.Text = "добавить";
            button16.UseVisualStyleBackColor = true;
            button16.Click += button16_Click;
            // 
            // textBox11
            // 
            textBox11.Dock = DockStyle.Top;
            textBox11.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox11.Location = new Point(285, 77);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(747, 39);
            textBox11.TabIndex = 19;
            textBox11.Text = "Введите имя";
            // 
            // textBox10
            // 
            textBox10.Dock = DockStyle.Top;
            textBox10.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox10.Location = new Point(285, 38);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(747, 39);
            textBox10.TabIndex = 17;
            textBox10.Text = "Введите фамилию";
            // 
            // listBox15
            // 
            listBox15.Dock = DockStyle.Left;
            listBox15.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            listBox15.FormattingEnabled = true;
            listBox15.ItemHeight = 27;
            listBox15.Location = new Point(3, 38);
            listBox15.Name = "listBox15";
            listBox15.Size = new Size(282, 568);
            listBox15.TabIndex = 16;
            // 
            // pictureBox8
            // 
            pictureBox8.BackColor = Color.White;
            pictureBox8.BorderStyle = BorderStyle.Fixed3D;
            pictureBox8.Dock = DockStyle.Right;
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(1032, 38);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(39, 568);
            pictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox8.TabIndex = 15;
            pictureBox8.TabStop = false;
            pictureBox8.Click += pictureBox8_Click;
            // 
            // comboBox8
            // 
            comboBox8.Dock = DockStyle.Top;
            comboBox8.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox8.FormattingEnabled = true;
            comboBox8.Location = new Point(3, 3);
            comboBox8.Name = "comboBox8";
            comboBox8.Size = new Size(1068, 35);
            comboBox8.TabIndex = 2;
            comboBox8.Text = "Класс";
            // 
            // tabPage22
            // 
            tabPage22.Controls.Add(pictureBox7);
            tabPage22.Controls.Add(comboBox7);
            tabPage22.Controls.Add(button18);
            tabPage22.Controls.Add(textBox12);
            tabPage22.Location = new Point(4, 34);
            tabPage22.Name = "tabPage22";
            tabPage22.Size = new Size(1074, 609);
            tabPage22.TabIndex = 2;
            tabPage22.Text = "Кл.рук";
            tabPage22.UseVisualStyleBackColor = true;
            // 
            // pictureBox7
            // 
            pictureBox7.BackColor = Color.White;
            pictureBox7.BorderStyle = BorderStyle.Fixed3D;
            pictureBox7.Dock = DockStyle.Left;
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(0, 74);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(39, 487);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 24;
            pictureBox7.TabStop = false;
            pictureBox7.Click += pictureBox7_Click;
            // 
            // comboBox7
            // 
            comboBox7.Dock = DockStyle.Top;
            comboBox7.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox7.FormattingEnabled = true;
            comboBox7.Location = new Point(0, 39);
            comboBox7.Name = "comboBox7";
            comboBox7.Size = new Size(1074, 35);
            comboBox7.TabIndex = 23;
            comboBox7.Text = "Класс";
            // 
            // button18
            // 
            button18.Dock = DockStyle.Bottom;
            button18.FlatStyle = FlatStyle.Popup;
            button18.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button18.Location = new Point(0, 561);
            button18.Name = "button18";
            button18.Size = new Size(1074, 48);
            button18.TabIndex = 22;
            button18.Text = "Сохранить...";
            button18.UseVisualStyleBackColor = true;
            button18.Click += button18_Click;
            // 
            // textBox12
            // 
            textBox12.Cursor = Cursors.IBeam;
            textBox12.Dock = DockStyle.Top;
            textBox12.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox12.Location = new Point(0, 0);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(1074, 39);
            textBox12.TabIndex = 18;
            // 
            // tabPage16
            // 
            tabPage16.Controls.Add(tabControl10);
            tabPage16.Location = new Point(4, 34);
            tabPage16.Name = "tabPage16";
            tabPage16.Size = new Size(1082, 647);
            tabPage16.TabIndex = 3;
            tabPage16.Text = "Список предметов";
            tabPage16.UseVisualStyleBackColor = true;
            // 
            // tabControl10
            // 
            tabControl10.Controls.Add(tabPage24);
            tabControl10.Dock = DockStyle.Fill;
            tabControl10.Location = new Point(0, 0);
            tabControl10.Name = "tabControl10";
            tabControl10.SelectedIndex = 0;
            tabControl10.Size = new Size(1082, 647);
            tabControl10.TabIndex = 0;
            // 
            // tabPage24
            // 
            tabPage24.Controls.Add(comboBox10);
            tabPage24.Controls.Add(listBox5);
            tabPage24.Controls.Add(button10);
            tabPage24.Controls.Add(pictureBox15);
            tabPage24.Controls.Add(pictureBox4);
            tabPage24.Controls.Add(comboBox1);
            tabPage24.Location = new Point(4, 24);
            tabPage24.Name = "tabPage24";
            tabPage24.Padding = new Padding(3);
            tabPage24.Size = new Size(1074, 619);
            tabPage24.TabIndex = 0;
            tabPage24.Text = "Добавить";
            tabPage24.UseVisualStyleBackColor = true;
            // 
            // comboBox10
            // 
            comboBox10.Dock = DockStyle.Bottom;
            comboBox10.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox10.FormattingEnabled = true;
            comboBox10.Location = new Point(42, 493);
            comboBox10.Name = "comboBox10";
            comboBox10.Size = new Size(1029, 35);
            comboBox10.TabIndex = 28;
            comboBox10.Text = "Предмет";
            comboBox10.SelectedIndexChanged += comboBox10_SelectedIndexChanged;
            comboBox10.Click += comboBox10_SelectedIndexChanged;
            // 
            // listBox5
            // 
            listBox5.Dock = DockStyle.Fill;
            listBox5.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 204);
            listBox5.FormattingEnabled = true;
            listBox5.ItemHeight = 32;
            listBox5.Location = new Point(42, 38);
            listBox5.Name = "listBox5";
            listBox5.Size = new Size(1029, 490);
            listBox5.TabIndex = 27;
            // 
            // button10
            // 
            button10.Dock = DockStyle.Bottom;
            button10.FlatStyle = FlatStyle.Popup;
            button10.Font = new Font("Microsoft JhengHei", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button10.Location = new Point(42, 528);
            button10.Name = "button10";
            button10.Size = new Size(1029, 48);
            button10.TabIndex = 26;
            button10.Text = "добавить";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // pictureBox15
            // 
            pictureBox15.BackColor = Color.White;
            pictureBox15.BorderStyle = BorderStyle.Fixed3D;
            pictureBox15.Dock = DockStyle.Bottom;
            pictureBox15.Image = (Image)resources.GetObject("pictureBox15.Image");
            pictureBox15.Location = new Point(42, 576);
            pictureBox15.Name = "pictureBox15";
            pictureBox15.Size = new Size(1029, 40);
            pictureBox15.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox15.TabIndex = 25;
            pictureBox15.TabStop = false;
            pictureBox15.Click += pictureBox15_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.White;
            pictureBox4.BorderStyle = BorderStyle.Fixed3D;
            pictureBox4.Dock = DockStyle.Left;
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(3, 38);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(39, 578);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 23;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // comboBox1
            // 
            comboBox1.Dock = DockStyle.Top;
            comboBox1.Font = new Font("Microsoft JhengHei", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(3, 3);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(1068, 35);
            comboBox1.TabIndex = 3;
            comboBox1.Text = "Класс";
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            comboBox1.Click += comboBox1_SelectedIndexChanged;
            // 
            // tabPage12
            // 
            tabPage12.Controls.Add(tabControl9);
            tabPage12.Location = new Point(4, 44);
            tabPage12.Name = "tabPage12";
            tabPage12.Size = new Size(1090, 685);
            tabPage12.TabIndex = 5;
            tabPage12.Text = "Объявления";
            tabPage12.UseVisualStyleBackColor = true;
            // 
            // tabControl9
            // 
            tabControl9.Controls.Add(tabPage21);
            tabControl9.Controls.Add(tabPage23);
            tabControl9.Dock = DockStyle.Fill;
            tabControl9.HotTrack = true;
            tabControl9.ItemSize = new Size(130, 30);
            tabControl9.Location = new Point(0, 0);
            tabControl9.Margin = new Padding(0);
            tabControl9.Name = "tabControl9";
            tabControl9.Padding = new Point(8, 3);
            tabControl9.SelectedIndex = 0;
            tabControl9.Size = new Size(1090, 685);
            tabControl9.SizeMode = TabSizeMode.Fixed;
            tabControl9.TabIndex = 6;
            // 
            // tabPage21
            // 
            tabPage21.AllowDrop = true;
            tabPage21.BackColor = Color.GhostWhite;
            tabPage21.Controls.Add(textBox13);
            tabPage21.Controls.Add(button17);
            tabPage21.Controls.Add(textBox9);
            tabPage21.Font = new Font("Agency FB", 15.75F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            tabPage21.ForeColor = SystemColors.ControlText;
            tabPage21.ImeMode = ImeMode.On;
            tabPage21.Location = new Point(4, 34);
            tabPage21.Name = "tabPage21";
            tabPage21.Padding = new Padding(3);
            tabPage21.Size = new Size(1082, 647);
            tabPage21.TabIndex = 0;
            tabPage21.Text = "Создать ";
            // 
            // textBox13
            // 
            textBox13.Cursor = Cursors.IBeam;
            textBox13.Dock = DockStyle.Fill;
            textBox13.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            textBox13.Location = new Point(3, 30);
            textBox13.Multiline = true;
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(1076, 568);
            textBox13.TabIndex = 6;
            textBox13.Text = "Текст объявления...";
            // 
            // button17
            // 
            button17.AutoSize = true;
            button17.BackColor = Color.WhiteSmoke;
            button17.BackgroundImageLayout = ImageLayout.Center;
            button17.Dock = DockStyle.Bottom;
            button17.FlatStyle = FlatStyle.Popup;
            button17.Font = new Font("Microsoft JhengHei", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button17.Location = new Point(3, 598);
            button17.Name = "button17";
            button17.Size = new Size(1076, 46);
            button17.TabIndex = 4;
            button17.Text = "Сохранить";
            button17.UseVisualStyleBackColor = false;
            button17.Click += button17_Click;
            // 
            // textBox9
            // 
            textBox9.Cursor = Cursors.IBeam;
            textBox9.Dock = DockStyle.Top;
            textBox9.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            textBox9.Location = new Point(3, 3);
            textBox9.Multiline = true;
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(1076, 27);
            textBox9.TabIndex = 1;
            textBox9.Text = "Заголовок...";
            // 
            // tabPage23
            // 
            tabPage23.BackColor = Color.White;
            tabPage23.Controls.Add(listBox13);
            tabPage23.Controls.Add(pictureBox12);
            tabPage23.Controls.Add(button19);
            tabPage23.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 204);
            tabPage23.Location = new Point(4, 34);
            tabPage23.Name = "tabPage23";
            tabPage23.Padding = new Padding(3);
            tabPage23.Size = new Size(1082, 647);
            tabPage23.TabIndex = 1;
            tabPage23.Text = "Удалить";
            // 
            // listBox13
            // 
            listBox13.Dock = DockStyle.Fill;
            listBox13.FormattingEnabled = true;
            listBox13.ItemHeight = 25;
            listBox13.Location = new Point(3, 52);
            listBox13.Name = "listBox13";
            listBox13.Size = new Size(1076, 552);
            listBox13.TabIndex = 6;
            // 
            // pictureBox12
            // 
            pictureBox12.BackColor = Color.White;
            pictureBox12.BorderStyle = BorderStyle.Fixed3D;
            pictureBox12.Dock = DockStyle.Bottom;
            pictureBox12.Image = (Image)resources.GetObject("pictureBox12.Image");
            pictureBox12.Location = new Point(3, 604);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(1076, 40);
            pictureBox12.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox12.TabIndex = 5;
            pictureBox12.TabStop = false;
            pictureBox12.Click += pictureBox12_Click;
            // 
            // button19
            // 
            button19.AutoSize = true;
            button19.BackColor = Color.WhiteSmoke;
            button19.BackgroundImageLayout = ImageLayout.Center;
            button19.Dock = DockStyle.Top;
            button19.FlatStyle = FlatStyle.Popup;
            button19.Font = new Font("Microsoft JhengHei", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button19.Location = new Point(3, 3);
            button19.Name = "button19";
            button19.Size = new Size(1076, 49);
            button19.TabIndex = 3;
            button19.Text = "удалить";
            button19.UseVisualStyleBackColor = false;
            button19.Click += button19_Click;
            // 
            // MainAdmin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1098, 777);
            Controls.Add(tabControl3);
            Controls.Add(panel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "MainAdmin";
            Text = "MainAdmin";
            Load += MainAdmin_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            tabControl2.ResumeLayout(false);
            TabPage3.ResumeLayout(false);
            TabPage3.PerformLayout();
            tabPage4.ResumeLayout(false);
            tabControl3.ResumeLayout(false);
            tabPage5.ResumeLayout(false);
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            tabPage6.ResumeLayout(false);
            tabControl4.ResumeLayout(false);
            tabPage7.ResumeLayout(false);
            tabPage7.PerformLayout();
            tabPage8.ResumeLayout(false);
            tabPage8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            tabPage9.ResumeLayout(false);
            tabControl5.ResumeLayout(false);
            tabPage13.ResumeLayout(false);
            tabPage13.PerformLayout();
            tabPage14.ResumeLayout(false);
            tabPage14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            tabPage10.ResumeLayout(false);
            tabControl6.ResumeLayout(false);
            tabPage15.ResumeLayout(false);
            tabPage15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            tabPage11.ResumeLayout(false);
            tabControl7.ResumeLayout(false);
            tabPage17.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            tabPage18.ResumeLayout(false);
            tabPage18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            tabPage19.ResumeLayout(false);
            tabControl8.ResumeLayout(false);
            tabPage20.ResumeLayout(false);
            tabPage20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            tabPage22.ResumeLayout(false);
            tabPage22.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            tabPage16.ResumeLayout(false);
            tabControl10.ResumeLayout(false);
            tabPage24.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox15).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            tabPage12.ResumeLayout(false);
            tabControl9.ResumeLayout(false);
            tabPage21.ResumeLayout(false);
            tabPage21.PerformLayout();
            tabPage23.ResumeLayout(false);
            tabPage23.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button button1;
        public TextBox textBox1;
        private TabControl tabControl2;
        private TabPage TabPage3;
        private Button button12;
        private TextBox textBox3;
        private TabPage tabPage4;
        private Button button13;
        public ListBox listBox2;
        private Button button14;
        private TabControl tabControl3;
        private TabPage tabPage5;
        private TabPage tabPage6;
        private Button button2;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private Button button7;
        private TabPage tabPage2;
        private PictureBox pictureBox1;
        public ListBox listBox1;
        private Button button8;
        private TabControl tabControl4;
        private TabPage tabPage7;
        private TabPage tabPage8;
        private TextBox textBox4;
        private Label label1;
        private Button button3;
        private Label label3;
        private Label label2;
        private Label label4;
        private TextBox textBox6;
        private TextBox textBox5;
        public ListBox listBox3;
        private PictureBox pictureBox2;
        private Button button4;
        private TabPage tabPage9;
        private TabPage tabPage10;
        private TabPage tabPage11;
        private TabPage tabPage12;
        private TabControl tabControl5;
        private TabPage tabPage13;
        private TabPage tabPage14;
        private PictureBox pictureBox3;
        public ListBox listBox4;
        private Button button6;
        private Button button5;
        private TextBox textBox8;
        private TextBox textBox7;
        private TabControl tabControl6;
        private TabPage tabPage15;
        private Button button9;
        private ComboBox comboBox2;
        public ListBox listBox6;
        private ComboBox comboBox3;
        private PictureBox pictureBox5;
        private Label label5;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        public ListBox listBox11;
        public ListBox listBox10;
        public ListBox listBox9;
        public ListBox listBox8;
        public ListBox listBox7;
        private ComboBox comboBox4;
        public ListBox listBox12;
        private TabControl tabControl7;
        private TabPage tabPage17;
        private TabPage tabPage18;
        private PictureBox pictureBox6;
        private Button button15;
        private ComboBox comboBox5;
        private ComboBox comboBox6;
        private Button button11;
        private TabPage tabPage19;
        private TabControl tabControl8;
        private TabPage tabPage20;
        private ComboBox comboBox8;
        private TabPage tabPage22;
        private PictureBox pictureBox8;
        public ListBox listBox15;
        private TextBox textBox10;
        private Button button16;
        private TextBox textBox11;
        private Button button18;
        private TextBox textBox12;
        public ListBox listBox14;
        private ComboBox comboBox9;
        private PictureBox pictureBox9;
        private PictureBox pictureBox10;
        private PictureBox pictureBox11;
        private PictureBox pictureBox7;
        private ComboBox comboBox7;
        private TabControl tabControl9;
        private TabPage tabPage21;
        private TabPage tabPage23;
        public ListBox listBox13;
        private PictureBox pictureBox12;
        private Button button19;
        private TextBox textBox2;
        private TextBox textBox9;
        private Button button17;
        private TextBox textBox13;
        private Label label11;
        private PictureBox pictureBox13;
        private PictureBox pictureBox14;
        private TabPage tabPage16;
        private TabControl tabControl10;
        private TabPage tabPage24;
        private PictureBox pictureBox15;
        private PictureBox pictureBox4;
        private ComboBox comboBox1;
        private ListBox listBox5;
        private Button button10;
        private ComboBox comboBox10;
    }
}