﻿using System.IO;

namespace WinFormsApp1
{
    internal static class AppNuget
    {
        public static string SetPathToJson { get; private set; }

        static AppNuget()
        {
            SetPathToJson = Directory.GetCurrentDirectory() + "\\ConnectionString.json";
        }
       
        public static void SerealiseConnectionString(string data) 
        {
            try 
            {
                using (FileStream fileStream = new FileStream(SetPathToJson , FileMode.Open , FileAccess.Write , FileShare.ReadWrite)) 
                {
                    using (StreamWriter streamReader = new(fileStream)) 
                    {
                        fileStream.SetLength(0);
                        streamReader.Write(data);
                        MessageBox.Show(data , "Сохранение..." , MessageBoxButtons.OK , MessageBoxIcon.Information);
                    }
                }
            }
            catch(Exception ex) 
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK , MessageBoxIcon.Error);
            }
        }
        public static string GetSerealizedString() 
        {
            try
            {
                using (FileStream fileStream = new FileStream(SetPathToJson, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                {
                    using (StreamReader streamReader = new(fileStream))
                    {
                        return streamReader.ReadToEnd();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return ex.Message;
            }
        }
        public static string[] GetSurnameName(ref string NS) 
        {
            string[] strs = { "", "" };
            int iterationstate = 0;
            for (ref int i = ref iterationstate; i <= NS.Length - 1; i++)
            {
                if (NS[i] == ' ')
                {
                    iterationstate = i + 1;
                    break;
                }
                strs[0] += NS[i];
            }
            for (ref int i = ref iterationstate; i <= NS.Length - 1; i++)
            {
                strs[1] += NS[i];
            }
           
            return strs;
        }
    }
}
