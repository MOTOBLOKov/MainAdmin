﻿using Microsoft.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class MainAdmin : Form
    {
        public MainAdmin()
        {
            InitializeComponent();
        }
        private void MainAdmin_Load(object sender, EventArgs e)
        {
            textBox1.Text = AppNuget.GetSerealizedString();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("сохранить строку подключения?", "Строка подключения", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                AppNuget.SerealiseConnectionString(textBox1.Text);
                Application.Exit();
            }
        }
        private async void button7_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(textBox2.Text))
                {
                    SqlSetup.StartNonExecuteQuery($"USE LESSONS INSERT INTO LESSONSITEMS(ITEMS) VALUES('{textBox2.Text.Trim()}');");
                    MessageBox.Show($"Успешно добавлено - {textBox2.Text}", "Database", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    using (SqlConnection connection = new SqlConnection(AppNuget.GetSerealizedString()))
                    {
                        if (connection.State == System.Data.ConnectionState.Closed)
                        {
                            await connection.OpenAsync();
                        }
                        using (SqlCommand sqlCommand = new("USE LESSONS SELECT * FROM LESSONSITEMS", connection))
                        {
                            using (SqlDataReader reader = await sqlCommand.ExecuteReaderAsync())
                            {
                                if (reader.HasRows)
                                {
                                    listBox12.Items.Clear();
                                    listBox12.Items.Add("Список текущих предметов:");
                                    while (await reader.ReadAsync())
                                    {
                                        listBox12.Items.Add(reader.GetValue(0).ToString());
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Пустое поле ввода", "TextBох", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private async void button8_Click_1(object sender, EventArgs e)
        {
            try
            {
                SqlSetup.StartNonExecuteQuery($"USE LESSONS DELETE FROM LESSONSITEMS WHERE ITEMS = '{listBox1.SelectedItem.ToString()}'");
                MessageBox.Show($"Предмет {listBox1.SelectedItem.ToString()} был удалён", "DataBase", MessageBoxButtons.OK, MessageBoxIcon.Information);
                listBox1.Items.Clear();
                using (SqlConnection sqlConnection = new SqlConnection(AppNuget.GetSerealizedString()))
                {
                    using (SqlCommand sqlCommand = new SqlCommand("USE LESSONS SELECT * FROM LESSONSITEMS", sqlConnection))
                    {
                        if (sqlConnection.State == System.Data.ConnectionState.Closed)
                        {
                            await sqlConnection.OpenAsync();
                        }
                        using (SqlDataReader sqlreader = await sqlCommand.ExecuteReaderAsync())
                        {
                            if (sqlreader.HasRows)
                            {
                                while (await sqlreader.ReadAsync())
                                {
                                    object data = sqlreader.GetValue(0);
                                    listBox1.Items.Add(data.ToString());
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Настроить конфигурацию базы данных?", "Database", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                SqlSetup.SetSqlInterface();
            }
        }

        private async void pictureBox1_Click_1(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            using (SqlConnection sqlConnection = new SqlConnection(AppNuget.GetSerealizedString()))
            {
                using (SqlCommand sqlCommand = new SqlCommand("USE LESSONS SELECT * FROM LESSONSITEMS", sqlConnection))
                {
                    if (sqlConnection.State == System.Data.ConnectionState.Closed)
                    {
                        await sqlConnection.OpenAsync();
                    }
                    using (SqlDataReader sqlreader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (sqlreader.HasRows)
                        {
                            while (await sqlreader.ReadAsync())
                            {
                                listBox1.Items.Add(sqlreader.GetValue(0).ToString());
                            }
                        }
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(textBox4.Text) && !string.IsNullOrWhiteSpace(textBox5.Text) && !string.IsNullOrWhiteSpace(textBox6.Text))
                {
                    SqlSetup.AddTeacher(textBox4.Text.Trim(), textBox5.Text.Trim(), textBox6.Text.Trim());
                    MessageBox.Show($"Учитель с ФИО - {textBox4.Text} {textBox5.Text} {textBox6.Text}\nБыл добавлен в базу данных", "DataBase", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Поля ввода являются пустыми", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void pictureBox2_Click(object sender, EventArgs e)
        {
            listBox3.Items.Clear();
            using (SqlConnection sqlConnection = new SqlConnection(AppNuget.GetSerealizedString()))
            {
                using (SqlCommand sqlCommand = new SqlCommand("USE TEACHERS SELECT * FROM PERSON", sqlConnection))
                {
                    if (sqlConnection.State == System.Data.ConnectionState.Closed)
                    {
                        await sqlConnection.OpenAsync();
                    }
                    using (SqlDataReader sqlreader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (sqlreader.HasRows)
                        {
                            while (await sqlreader.ReadAsync())
                            {
                                listBox3.Items.Add(sqlreader.GetValue(0).ToString());
                            }
                        }
                    }
                }
            }
        }

        private async void button4_Click(object sender, EventArgs e)
        {
            try
            {
                string SNL = listBox3.SelectedItem.ToString();
                SqlSetup.StartNonExecuteQuery($"USE TEACHERS DELETE FROM PERSON WHERE SNL = '{SNL}';");
                MessageBox.Show($"Учитель с ФИО - {SNL}\nБыл удалён из базы данных", "Database", MessageBoxButtons.OK, MessageBoxIcon.Information);
                listBox3.Items.Clear();
                using (SqlConnection sqlConnection = new SqlConnection(AppNuget.GetSerealizedString()))
                {
                    using (SqlCommand sqlCommand = new SqlCommand("USE TEACHERS SELECT * FROM PERSON", sqlConnection))
                    {
                        if (sqlConnection.State == System.Data.ConnectionState.Closed)
                        {
                            await sqlConnection.OpenAsync();
                        }
                        using (SqlDataReader sqlreader = await sqlCommand.ExecuteReaderAsync())
                        {
                            if (sqlreader.HasRows)
                            {
                                while (await sqlreader.ReadAsync())
                                {
                                    object info = sqlreader.GetValue(0);
                                    listBox3.Items.Add(info.ToString());
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox7.Text) && !string.IsNullOrWhiteSpace(textBox8.Text))
            {

                if (textBox7.Text.Trim().Length <= 4)
                {
                    MessageBox.Show("Расписание звонков вводится в 24-часавом формате\nПример - 08:05", "DataBase", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (textBox7.Text.Trim().Length >= 6)
                {
                    MessageBox.Show("Расписание звонков вводится в 24-часавом формате\nПример - 08:05", "DataBase", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (textBox8.Text.Trim().Length <= 4)
                {
                    MessageBox.Show("Расписание звонков вводится в 24-часавом формате\nПример - 08:05", "DataBase", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (textBox8.Text.Trim().Length >= 6)
                {
                    MessageBox.Show("Расписание звонков вводится в 24-часавом формате\nПример - 08:05", "DataBase", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                SqlSetup.StartNonExecuteQuery($"USE CALLSCHEDULE INSERT INTO CALLTIMES(STARTTIME , ENDTIME) VALUES('{textBox7.Text}','{textBox8.Text}')");
                MessageBox.Show($"Начало урока {textBox7.Text.Trim()}\nКонец урока {textBox8.Text.Trim()}", "DataBase", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Пустые поля ввода", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void pictureBox3_Click(object sender, EventArgs e)
        {
            try
            {
                listBox4.Items.Clear();
                using (SqlConnection sqlConnection = new SqlConnection(AppNuget.GetSerealizedString()))
                {
                    using (SqlCommand sqlCommand = new SqlCommand("USE CALLSCHEDULE SELECT * FROM CALLTIMES", sqlConnection))
                    {
                        if (sqlConnection.State == System.Data.ConnectionState.Closed)
                        {
                            await sqlConnection.OpenAsync();
                        }
                        using (SqlDataReader sqlreader = await sqlCommand.ExecuteReaderAsync())
                        {
                            if (sqlreader.HasRows)
                            {
                                while (await sqlreader.ReadAsync())
                                {
                                    listBox4.Items.Add($"Начало: {sqlreader.GetValue(0)} конец: {sqlreader.GetValue(1)}");
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void button6_Click(object sender, EventArgs e)
        {
            try
            {
                string str = listBox4.SelectedItem.ToString();
                string startpoint = str[8..13];
                string endpoint = str[21..26];
                SqlSetup.StartNonExecuteQuery($"USE CALLSCHEDULE DELETE FROM CALLTIMES WHERE STARTTIME = '{startpoint}' AND ENDTIME = '{endpoint}';");
                MessageBox.Show($"Расписание удалено\n{startpoint}:{endpoint}", "Database", MessageBoxButtons.OK, MessageBoxIcon.Information);
                listBox4.Items.Clear();
                using (SqlConnection sqlConnection = new SqlConnection(AppNuget.GetSerealizedString()))
                {
                    using (SqlCommand sqlCommand = new SqlCommand("USE CALLSCHEDULE SELECT * FROM CALLTIMES", sqlConnection))
                    {
                        if (sqlConnection.State == System.Data.ConnectionState.Closed)
                        {
                            await sqlConnection.OpenAsync();
                        }
                        using (SqlDataReader sqlreader = await sqlCommand.ExecuteReaderAsync())
                        {
                            if (sqlreader.HasRows)
                            {
                                while (await sqlreader.ReadAsync())
                                {
                                    listBox4.Items.Add($"Начало: {sqlreader.GetValue(0)} конец: {sqlreader.GetValue(1)}");
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private async void button9_Click(object sender, EventArgs e)
        {
            try
            {
                string column = comboBox2.SelectedItem.ToString() switch
                {
                    "Понедельник" => "PONEDELNIK",
                    "Вторник" => "VTORNIK",
                    "Среда" => "SREDA",
                    "Четверг" => "CHETVERG",
                    "Пятница" => "PYATNITZA",
                    "Суббота" => "SYBOTA"
                };
                SqlSetup.StartNonExecuteQuery($"USE SCHOOLSCHEDULE INSERT INTO {comboBox4.SelectedItem} ({column}) VALUES('{comboBox3.SelectedItem}')");
                using (SqlConnection connection = new SqlConnection(AppNuget.GetSerealizedString()))
                {
                    if (connection.State == System.Data.ConnectionState.Closed)
                    {
                        await connection.OpenAsync();
                    }
                    using (SqlCommand command = new SqlCommand($"USE SCHOOLSCHEDULE SELECT * FROM {comboBox4.SelectedItem}", connection))
                    {
                        using (SqlDataReader reader = await command.ExecuteReaderAsync())
                        {
                            listBox6.Items.Clear();
                            listBox7.Items.Clear();
                            listBox8.Items.Clear();
                            listBox9.Items.Clear();
                            listBox10.Items.Clear();
                            listBox11.Items.Clear();
                            if (reader.HasRows)
                            {
                                while (await reader.ReadAsync())
                                {
                                    if (!string.IsNullOrEmpty(reader.GetValue(0).ToString()))
                                        listBox6.Items.Add(reader.GetValue(0));

                                    if (!string.IsNullOrEmpty(reader.GetValue(1).ToString()))
                                        listBox7.Items.Add(reader.GetValue(1));

                                    if (!string.IsNullOrEmpty(reader.GetValue(2).ToString()))
                                        listBox8.Items.Add(reader.GetValue(2));

                                    if (!string.IsNullOrEmpty(reader.GetValue(3).ToString()))
                                        listBox9.Items.Add(reader.GetValue(3));

                                    if (!string.IsNullOrEmpty(reader.GetValue(4).ToString()))
                                        listBox10.Items.Add(reader.GetValue(4));

                                    if (!string.IsNullOrEmpty(reader.GetValue(5).ToString()))
                                        listBox11.Items.Add(reader.GetValue(5));
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void pictureBox5_Click(object sender, EventArgs e)
        {
            try
            {

                comboBox3.Items.Clear();
                comboBox4.Items.Clear();

                using (SqlConnection connection = new SqlConnection(AppNuget.GetSerealizedString()))
                {
                    if (connection.State == System.Data.ConnectionState.Closed)
                    {
                        await connection.OpenAsync();
                    }
                    using (SqlCommand command = new SqlCommand("USE LESSONS SELECT * FROM LESSONSITEMS", connection))
                    {
                        using (SqlDataReader sqlCommand = await command.ExecuteReaderAsync())
                        {
                            if (sqlCommand.HasRows)
                            {
                                while (await sqlCommand.ReadAsync())
                                {
                                    comboBox3.Items.Add(sqlCommand.GetValue(0).ToString());
                                }
                            }
                        }
                    }
                    using (SqlCommand command1 = new SqlCommand("USE CLASSROOMS SELECT * FROM sys.objects WHERE type in (N'U')", connection))
                    {
                        using (SqlDataReader sqlCommand = await command1.ExecuteReaderAsync())
                        {
                            if (sqlCommand.HasRows)
                            {
                                while (await sqlCommand.ReadAsync())
                                {
                                    if (sqlCommand.GetValue(0).ToString() != "CLASSROOMTEACHER")
                                        comboBox4.Items.Add(sqlCommand.GetValue(0).ToString());
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }



        private void button11_Click(object sender, EventArgs e)
        {
            string comand = null;
            string finaly = comboBox5.SelectedItem.ToString() + comboBox6.SelectedItem.ToString();
            try
            {
                switch (comboBox5.SelectedItem.ToString())
                {
                    case "1":
                        comand = "ONE";
                        break;
                    case "2":
                        comand = "TWOO";
                        break;
                    case "3":
                        comand = "THRE";
                        break;
                    case "4":
                        comand = "FORE";
                        break;
                    case "5":
                        comand = "FIVE";
                        break;
                    case "6":
                        comand = "SIX";
                        break;
                    case "7":
                        comand = "SEVEN";
                        break;
                    case "8":
                        comand = "EIGHT";
                        break;
                    case "9":
                        comand = "NINE";
                        break;
                    case "10":
                        comand = "TEN";
                        break;
                    case "11":
                        comand = "ELEVEN";
                        break;
                }

                switch (comboBox6.SelectedItem.ToString())
                {
                    case "А":
                        comand += "a";
                        break;
                    case "Б":
                        comand += "b";
                        break;
                    case "В":
                        comand += "v";
                        break;
                    case "Г":
                        comand += "g";
                        break;
                    case "Д":
                        comand += "d";
                        break;
                    case "Е":
                        comand += "e";
                        break;
                }
                SqlSetup.AddClassroom(comand, comboBox9.SelectedItem.ToString());

                MessageBox.Show($"Создан класс: {finaly}\nРуководитель: {comboBox9.SelectedItem}", "Database", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void pictureBox6_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new(AppNuget.GetSerealizedString()))
            {
                if (con.State == System.Data.ConnectionState.Closed)
                {
                    await con.OpenAsync();
                }

                using (SqlCommand com = new("USE CLASSROOMS SELECT * FROM sys.objects WHERE type in (N'U')", con))
                {
                    using (SqlDataReader read = await com.ExecuteReaderAsync())
                    {
                        listBox14.Items.Clear();
                        if (read.HasRows)
                        {
                            while (await read.ReadAsync())
                            {
                                if (read.GetValue(0).ToString() != "CLASSROOMTEACHER")
                                {
                                    listBox14.Items.Add(read.GetValue(0).ToString());
                                }
                            }
                        }
                    }
                }
            }
        }
        private async void button15_Click(object sender, EventArgs e)
        {
            try
            {

                using (SqlConnection con = new(AppNuget.GetSerealizedString()))
                {
                    if (con.State == System.Data.ConnectionState.Closed)
                    {
                        await con.OpenAsync();
                    }
                    using (SqlCommand command = new SqlCommand($"USE CLASSROOMS DELETE FROM CLASSROOMTEACHER WHERE CLASSROOM = '{listBox14.SelectedItem}'", con))
                    {
                        await command.ExecuteNonQueryAsync();
                        SqlSetup.StartNonExecuteQuery($"USE CLASSROOMS DROP TABLE {listBox14.SelectedItem};USE SCHOOLSCHEDULE DROP TABLE {listBox14.SelectedItem};USE CLASESITEMS DROP TABLE {listBox14.Text};");
                        MessageBox.Show($"{listBox14.SelectedItem} был удалён", "DataBase", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        listBox14.Items.Clear();
                    }
                    using (SqlCommand com = new("USE CLASSROOMS SELECT * FROM sys.objects WHERE type in (N'U')", con))
                    {
                        using (SqlDataReader read = await com.ExecuteReaderAsync())
                        {
                            if (read.HasRows)
                            {
                                while (await read.ReadAsync())
                                {
                                    if (read.GetValue(0).ToString() != "CLASSROOMTEACHER")
                                    {
                                        listBox14.Items.Add(read.GetValue(0));
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
        private async void pictureBox9_Click(object sender, EventArgs e)
        {
            try
            {
                comboBox9.Items.Clear();
                using (SqlConnection sqlConnection = new SqlConnection(AppNuget.GetSerealizedString()))
                {
                    if (sqlConnection.State == System.Data.ConnectionState.Closed)
                    {
                        await sqlConnection.OpenAsync();
                    }
                    using (SqlCommand command = new SqlCommand("USE TEACHERS SELECT SNL FROM PERSON", sqlConnection))
                    {
                        using (SqlDataReader sqlDataReader = await command.ExecuteReaderAsync())
                        {
                            if (sqlDataReader.HasRows)
                            {
                                while (await sqlDataReader.ReadAsync())
                                {
                                    comboBox9.Items.Add(sqlDataReader.GetValue(0));
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
        private async void pictureBox8_Click(object sender, EventArgs e)
        {
            try
            {
                comboBox8.Items.Clear();
                using (SqlConnection con = new(AppNuget.GetSerealizedString()))
                {
                    if (con.State == System.Data.ConnectionState.Closed)
                    {
                        await con.OpenAsync();
                    }

                    using (SqlCommand com = new("USE CLASSROOMS SELECT * FROM sys.objects WHERE type in (N'U')", con))
                    {
                        using (SqlDataReader read = await com.ExecuteReaderAsync())
                        {
                            if (read.HasRows)
                            {

                                while (await read.ReadAsync())
                                {
                                    if (read.GetValue(0).ToString() != "CLASSROOMTEACHER")
                                    {
                                        comboBox8.Items.Add(read.GetValue(0).ToString());
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void pictureBox10_Click(object sender, EventArgs e)
        {
            try
            {
                listBox15.Items.Clear();
                using (SqlConnection con = new(AppNuget.GetSerealizedString()))
                {
                    if (con.State == System.Data.ConnectionState.Closed)
                    {
                        await con.OpenAsync();
                    }
                    using (SqlCommand com = new($"USE CLASSROOMS SELECT * FROM {comboBox8.SelectedItem}", con))
                    {
                        using (var reader = await com.ExecuteReaderAsync())
                        {
                            if (reader.HasRows)
                            {
                                while (await reader.ReadAsync())
                                {
                                    listBox15.Items.Add($"{reader.GetValue(0)} {reader.GetValue(1)}");
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private async void button16_Click(object sender, EventArgs e)
        {
            try
            {
                string? sqlitems = null;
                using (SqlConnection con = new SqlConnection(AppNuget.GetSerealizedString()))
                {
                    if (con.State == System.Data.ConnectionState.Closed)
                    {
                        await con.OpenAsync();
                    }
                    using (SqlCommand com = new SqlCommand($"USE CLASESITEMS SELECT ITEMS FROM {comboBox8.Text}", con))
                    {
                        using (SqlDataReader reader = await com.ExecuteReaderAsync())
                        {
                            if (reader.HasRows)
                            {
                                while (await reader.ReadAsync())
                                {
                                    sqlitems += reader.GetValue(0).ToString().Trim() + " NVARCHAR(MAX) COLLATE Cyrillic_General_100_CI_AS_SC_UTF8,";
                                }
                                sqlitems = sqlitems.Remove(sqlitems.Length - 1);
                            }
                        }
                    }
                }
                string fcomand = $"USE MARKS CREATE TABLE {textBox10.Text.Trim() + textBox11.Text.Trim()}({sqlitems});"; 
                MessageBox.Show(fcomand);
                MessageBox.Show($"USE CLASSROOMS INSERT INTO {comboBox8.SelectedItem}(SURNAME , NAME) VALUES('{textBox10.Text}','{textBox11.Text}');{fcomand}");
                SqlSetup.StartNonExecuteQuery($"USE CLASSROOMS INSERT INTO {comboBox8.SelectedItem}(SURNAME , NAME) VALUES('{textBox10.Text}','{textBox11.Text}');{fcomand}");
                MessageBox.Show($"Ученик - {textBox10.Text} {textBox11.Text}\nБыл добавлен в {comboBox8.SelectedItem}", "DataBase", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void pictureBox11_Click_1(object sender, EventArgs e)
        {
            try
            {
                string surnamename = listBox15.SelectedItem.ToString();
                string[] sn = AppNuget.GetSurnameName(ref surnamename);
                SqlSetup.StartNonExecuteQuery($"USE CLASSROOMS DELETE FROM {comboBox8.SelectedItem} WHERE SURNAME = '{sn[0]}' AND NAME = '{sn[1]}'");
                MessageBox.Show($"ученик - {sn[0]} {sn[1]} был удалён", "DataBase", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private async void pictureBox7_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(AppNuget.GetSerealizedString()))
            {
                if (con.State == System.Data.ConnectionState.Closed)
                {
                    await con.OpenAsync();
                }
                using (SqlCommand sqlCommand = new SqlCommand($"USE CLASSROOMS SELECT * FROM sys.objects WHERE type in (N'U')", con))
                {
                    using (SqlDataReader reader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync())
                            {
                                if (reader.GetValue(0).ToString() != "CLASSROOMTEACHER")
                                    comboBox7.Items.Add(reader.GetValue(0));
                            }
                        }
                    }
                }
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            try
            {
                SqlSetup.StartNonExecuteQuery($"USE CLASSROOMS UPDATE CLASSROOMTEACHER SET TEACHER = '{textBox12.Text}' WHERE CLASSROOM = '{comboBox7.SelectedItem}'");
                MessageBox.Show("Кл.Рук был обновлён", "DataBase", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void button17_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(textBox9.Text) && !string.IsNullOrWhiteSpace(textBox13.Text))
                {
                    SqlSetup.StartNonExecuteQuery($"USE ADS INSERT INTO INFO(TITLE,TEXT) VALUES('{textBox9.Text}','{textBox13.Text}')");
                    MessageBox.Show("Создано новое объявление", "DataBase", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Пустые поля", "DataBase", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void pictureBox12_Click(object sender, EventArgs e)
        {
            try
            {
                listBox13.Items.Clear();
                using (SqlConnection connection = new SqlConnection(AppNuget.GetSerealizedString()))
                {
                    if (connection.State == System.Data.ConnectionState.Closed)
                    {
                        await connection.OpenAsync();
                    }
                    using (SqlCommand command = new SqlCommand("USE ADS SELECT TITLE FROM INFO", connection))
                    {
                        using (SqlDataReader reader = await command.ExecuteReaderAsync())
                        {
                            if (reader.HasRows)
                            {
                                while (await reader.ReadAsync())
                                {
                                    listBox13.Items.Add(reader.GetValue(0));
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void button19_Click(object sender, EventArgs e)
        {
            try
            {
                SqlSetup.StartNonExecuteQuery($"USE ADS DELETE FROM INFO WHERE TITLE = '{listBox13.SelectedItem}';");
                MessageBox.Show($"Объявление с заголовком {listBox13.SelectedItem}\nБыло удалено", "DataBase", MessageBoxButtons.OK, MessageBoxIcon.Information);
                listBox13.Items.Clear();
                using (SqlConnection connection = new SqlConnection(AppNuget.GetSerealizedString()))
                {
                    if (connection.State == System.Data.ConnectionState.Closed)
                    {
                        await connection.OpenAsync();
                    }
                    using (SqlCommand command = new SqlCommand("USE ADS SELECT TITLE FROM INFO", connection))
                    {
                        using (SqlDataReader reader = await command.ExecuteReaderAsync())
                        {
                            if (reader.HasRows)
                            {
                                while (await reader.ReadAsync())
                                {
                                    listBox13.Items.Add(reader.GetValue(0));
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private delegate void CurrentDay();
        private CurrentDay currentDay;

        private void listBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            label11.Text = listBox6.SelectedItem.ToString();
            currentDay = delegate ()
            {
                SqlSetup.StartNonExecuteQuery($"USE SCHOOLSCHEDULE UPDATE {comboBox4.Text} SET PONEDELNIK = NULL WHERE PONEDELNIK = '{listBox6.Text}'; ");
            };
        }

        private void listBox7_SelectedIndexChanged(object sender, EventArgs e)
        {
            label11.Text = listBox7.SelectedItem.ToString();
            currentDay = delegate ()
            {
                SqlSetup.StartNonExecuteQuery($"USE SCHOOLSCHEDULE UPDATE {comboBox4.Text} SET VTORNIK = NULL WHERE VTORNIK = '{listBox7.Text}'; ");
            };
        }

        private void listBox8_SelectedIndexChanged(object sender, EventArgs e)
        {
            label11.Text = listBox8.SelectedItem.ToString();
            currentDay = delegate ()
            {
                SqlSetup.StartNonExecuteQuery($"USE SCHOOLSCHEDULE UPDATE {comboBox4.Text} SET SREDA = NULL WHERE SREDA = '{listBox8.Text}'; ");
            };
        }
        private void listBox9_SelectedIndexChanged(object sender, EventArgs e)
        {
            label11.Text = listBox9.SelectedItem.ToString();
            currentDay = delegate ()
            {
                SqlSetup.StartNonExecuteQuery($"USE SCHOOLSCHEDULE UPDATE {comboBox4.Text} SET CHETVERG = NULL WHERE CHETVERG = '{listBox9.Text}'; ");
            };
        }

        private void listBox10_SelectedIndexChanged(object sender, EventArgs e)
        {
            label11.Text = listBox10.SelectedItem.ToString();
            currentDay = delegate ()
            {
                SqlSetup.StartNonExecuteQuery($"USE SCHOOLSCHEDULE UPDATE {comboBox4.Text} SET PYATNITZA = NULL WHERE PYATNITZA = '{listBox10.Text}'; ");
            };
        }

        private void listBox11_SelectedIndexChanged(object sender, EventArgs e)
        {
            label11.Text = listBox11.SelectedItem.ToString();
            currentDay = delegate ()
            {
                SqlSetup.StartNonExecuteQuery($"USE SCHOOLSCHEDULE UPDATE {comboBox4.Text} SET SYBOTA = NULL WHERE SYBOTA = '{listBox11.Text}'; ");
            };
        }

        private async void pictureBox13_Click(object sender, EventArgs e)
        {
            try
            {
                await StartItemDelete();
                using (SqlConnection connection = new SqlConnection(AppNuget.GetSerealizedString()))
                {
                    if (connection.State == System.Data.ConnectionState.Closed)
                    {
                        await connection.OpenAsync();
                    }
                    using (SqlCommand command = new SqlCommand($"USE SCHOOLSCHEDULE SELECT * FROM {comboBox4.SelectedItem}", connection))
                    {
                        using (SqlDataReader reader = await command.ExecuteReaderAsync())
                        {
                            listBox6.Items.Clear();
                            listBox7.Items.Clear();
                            listBox8.Items.Clear();
                            listBox9.Items.Clear();
                            listBox10.Items.Clear();
                            listBox11.Items.Clear();
                            if (reader.HasRows)
                            {
                                while (await reader.ReadAsync())
                                {
                                    if (!string.IsNullOrEmpty(reader.GetValue(0).ToString()))
                                        listBox6.Items.Add(reader.GetValue(0));

                                    if (!string.IsNullOrEmpty(reader.GetValue(1).ToString()))
                                        listBox7.Items.Add(reader.GetValue(1));

                                    if (!string.IsNullOrEmpty(reader.GetValue(2).ToString()))
                                        listBox8.Items.Add(reader.GetValue(2));

                                    if (!string.IsNullOrEmpty(reader.GetValue(3).ToString()))
                                        listBox9.Items.Add(reader.GetValue(3));

                                    if (!string.IsNullOrEmpty(reader.GetValue(4).ToString()))
                                        listBox10.Items.Add(reader.GetValue(4));

                                    if (!string.IsNullOrEmpty(reader.GetValue(5).ToString()))
                                        listBox11.Items.Add(reader.GetValue(5));
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private Task StartItemDelete()
        {
            currentDay.Invoke();
            return Task.CompletedTask;
        }
        private async void pictureBox14_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(AppNuget.GetSerealizedString()))
                {
                    if (connection.State == System.Data.ConnectionState.Closed)
                    {
                        await connection.OpenAsync();
                    }
                    using (SqlCommand command = new SqlCommand($"USE SCHOOLSCHEDULE SELECT * FROM {comboBox4.SelectedItem}", connection))
                    {
                        using (SqlDataReader reader = await command.ExecuteReaderAsync())
                        {
                            listBox6.Items.Clear();
                            listBox7.Items.Clear();
                            listBox8.Items.Clear();
                            listBox9.Items.Clear();
                            listBox10.Items.Clear();
                            listBox11.Items.Clear();
                            if (reader.HasRows)
                            {
                                while (await reader.ReadAsync())
                                {
                                    if (!string.IsNullOrEmpty(reader.GetValue(0).ToString()))
                                        listBox6.Items.Add(reader.GetValue(0));

                                    if (!string.IsNullOrEmpty(reader.GetValue(1).ToString()))
                                        listBox7.Items.Add(reader.GetValue(1));

                                    if (!string.IsNullOrEmpty(reader.GetValue(2).ToString()))
                                        listBox8.Items.Add(reader.GetValue(2));

                                    if (!string.IsNullOrEmpty(reader.GetValue(3).ToString()))
                                        listBox9.Items.Add(reader.GetValue(3));

                                    if (!string.IsNullOrEmpty(reader.GetValue(4).ToString()))
                                        listBox10.Items.Add(reader.GetValue(4));

                                    if (!string.IsNullOrEmpty(reader.GetValue(5).ToString()))
                                        listBox11.Items.Add(reader.GetValue(5));
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void listBox14_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private async void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (SqlConnection con = new(AppNuget.GetSerealizedString()))
            {
                if (con.State == System.Data.ConnectionState.Closed)
                {
                    await con.OpenAsync();
                }

                using (SqlCommand com = new("USE CLASSROOMS SELECT * FROM sys.objects WHERE type in (N'U')", con))
                {
                    using (SqlDataReader read = await com.ExecuteReaderAsync())
                    {
                        comboBox1.Items.Clear();
                        if (read.HasRows)
                        {
                            while (await read.ReadAsync())
                            {
                                if (read.GetValue(0).ToString() != "CLASSROOMTEACHER")
                                {
                                    comboBox1.Items.Add(read.GetValue(0).ToString());
                                }
                            }
                        }
                    }
                }
            }
        }

        private async void pictureBox4_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new(AppNuget.GetSerealizedString()))
                {
                    if (con.State == System.Data.ConnectionState.Closed)
                    {
                        await con.OpenAsync();
                    }

                    using (SqlCommand com = new($"USE CLASESITEMS SELECT ITEMS FROM {comboBox1.Text}", con))
                    {
                        using (SqlDataReader read = await com.ExecuteReaderAsync())
                        {
                            listBox5.Items.Clear();
                            if (read.HasRows)
                            {
                                while (await read.ReadAsync())
                                {
                                    listBox5.Items.Add(read.GetValue(0).ToString());
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void comboBox10_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (SqlConnection con = new(AppNuget.GetSerealizedString()))
            {
                if (con.State == System.Data.ConnectionState.Closed)
                {
                    await con.OpenAsync();
                }

                using (SqlCommand com = new("USE LESSONS SELECT ITEMS FROM LESSONSITEMS", con))
                {
                    using (SqlDataReader read = await com.ExecuteReaderAsync())
                    {
                        comboBox10.Items.Clear();
                        if (read.HasRows)
                        {
                            while (await read.ReadAsync())
                            {
                                comboBox10.Items.Add(read.GetValue(0).ToString());
                            }
                        }
                    }
                }
            }
        }

        private async void button10_Click(object sender, EventArgs e)
        {
            SqlSetup.StartNonExecuteQuery($"USE CLASESITEMS INSERT INTO {comboBox1.Text}(ITEMS) VALUES('{comboBox10.Text}')");
            try
            {
                using (SqlConnection con = new(AppNuget.GetSerealizedString()))
                {
                    if (con.State == System.Data.ConnectionState.Closed)
                    {
                        await con.OpenAsync();
                    }

                    using (SqlCommand com = new($"USE CLASESITEMS SELECT ITEMS FROM {comboBox1.Text}", con))
                    {
                        using (SqlDataReader read = await com.ExecuteReaderAsync())
                        {
                            listBox5.Items.Clear();
                            if (read.HasRows)
                            {
                                while (await read.ReadAsync())
                                {
                                    listBox5.Items.Add(read.GetValue(0).ToString());
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void pictureBox15_Click(object sender, EventArgs e)
        {
            SqlSetup.StartNonExecuteQuery($"USE CLASESITEMS DELETE FROM {comboBox1.Text} WHERE ITEMS = '{listBox5.SelectedItem}'");
            try
            {
                using (SqlConnection con = new(AppNuget.GetSerealizedString()))
                {
                    if (con.State == System.Data.ConnectionState.Closed)
                    {
                        await con.OpenAsync();
                    }

                    using (SqlCommand com = new($"USE CLASESITEMS SELECT ITEMS FROM {comboBox1.Text}", con))
                    {
                        using (SqlDataReader read = await com.ExecuteReaderAsync())
                        {
                            listBox5.Items.Clear();
                            if (read.HasRows)
                            {
                                while (await read.ReadAsync())
                                {
                                    listBox5.Items.Add(read.GetValue(0).ToString());
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
