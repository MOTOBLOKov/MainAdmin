using System.IO;
namespace WinFormsApp1
{
    public partial class PasswordEntryForm : Form
    {
        public PasswordEntryForm()
        {
            InitializeComponent();
        }

        public MainAdmin Admin = new();
        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text += "1";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text += "2";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text += "3";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text += "4";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text += "5";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text += "6";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text += "7";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox1.Text += "8";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox1.Text += "9";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            textBox1.Text += "0";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "1488") { Admin.Show(); Hide(); }
            else { textBox1.Text = string.Empty; }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
        }

        private void PasswordEntryForm_Load(object sender, EventArgs e)
        {
            string path = Directory.GetCurrentDirectory();
            try
            {
                string pwd = path + "\\ConnectionString.json";
                if (!File.Exists(pwd))
                {
                    using (FileStream fs = new FileStream(pwd, FileMode.OpenOrCreate, FileAccess.Write, FileShare.ReadWrite))
                    {
                        using (StreamWriter sw = new StreamWriter(fs))
                        {
                            sw.WriteAsync("������� � ��������� ������ �����������...");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "������", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
